import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import NotFound from "./components/pages/404";
import Chart from "./components/pages/chart";
import Dashboard from "./components/pages/dashboard";
import EditProfile from "./components/pages/edit_page";
import Login from "./components/pages/login";
import Navbar from "./components/pages/navbar";
import Profile from "./components/pages/profile";
import Signup from "./components/pages/signup";


function App() {
  function checkAuthentication(){
    // check user token with backend
    return true
  }
  if (localStorage.getItem('token')!==null){
    if (checkAuthentication()===false){
      localStorage.setItem('token',null)
    }
  }
  else{
    if(localStorage.getItem('signupStatus')===1){
      return <Signup />
    }
    return <Login />
  }
  return (
    <>
    <Navbar />
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />  
        <Route path="login" element={<Login />} />
        <Route path="chart" element={<Chart />} />
        <Route path="profile" element={<Profile />} />
        <Route path="edit-profile" element={<EditProfile />} />
        <Route path="signup" element={<Signup />} />



        <Route path="*" element={<NotFound />} />
        {/* <Route path="users" element={<Users />}>
          <Route path="me" element={<OwnUserProfile />} />
          <Route path=":id" element={<UserProfile />} />
        </Route> */}
      </Routes>
    </BrowserRouter>
    </>
  );
}
export default App;