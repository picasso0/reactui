import { useState } from "react";
import axios from "axios";
import { useAlert } from 'react-alert'
import {  Navigate } from 'react-router-dom';


export default function Signup() {
	const alert = useAlert()
	const [email,setEmail]=useState()
	const [password,setPassword]=useState()
	const [username,setUsername]=useState()



	async function createAccount (signupInfo) {
		axios.post("http://127.0.0.1:8000/users/", 
        signupInfo
		  )
		  .then(function (response) {
			if(response.status===200){
				if (response.data.status===false){
					alert.error("user info not correct",)
				}
				else{
				localStorage.setItem('token',response.data.data.token.access)
				alert.success("loged in successfuly")
				window.location.reload(false);
				
				}
			}
		  })
		  .catch(function (error) {
			localStorage.setItem('token',"test")
			alert.success("network error")
			window.location.reload(false);
			console.log(error);
		  });
	}

	const handleSubmit = async e => {
		e.preventDefault();
		await createAccount({
		  'email':email,
		  'password':password,
          'username':username
		});
	  }

	if (localStorage.getItem('token')!==null){
		alert.show("you are loged in"
		)
		return <Navigate to="/?" />
	}
    return ( 
        <div className="d-flex justify-content-center h-100vh user bg-login">
		<div className="card">
			<div className="card-header">
				<h3>Sign Up</h3>
			</div>
			<div className="card-body">
				<form>
					<div className="input-group form-group">
						<div className="input-group-prepend">
							<span className="input-group-text"><i className="fas fa-user"></i></span>
						</div>
						<input type="email" className="form-control" onChange={e => setEmail(e.target.value)}  placeholder="username" />
					</div>
					<div className="input-group form-group">
						<div className="input-group-prepend">
							<span className="input-group-text"><i className="fas fa-key"></i></span>
						</div>
						<input type="password" onChange={e => setPassword(e.target.value)} className="form-control" placeholder="password" autoComplete="on" />
                        <input type="password" onChange={e => setPassword(e.target.value)} className="form-control" placeholder="verify password" autoComplete="on" />

					</div>
                    <div className="input-group form-group">
						<div className="input-group-prepend">
							<span className="input-group-text"><i className="fas fa-key"></i></span>
						</div>
                        <input type="password" onChange={e => setPassword(e.target.value)} className="form-control" placeholder="verify password" autoComplete="on" />

					</div>
					<div className="row p-2 justify-content-center">
						<input type="submit" onClick={ handleSubmit  } value="Signup" className="btn  float-right login_btn" />
						</div>
				</form>
				
			</div>
			<div className="card-footer">
				<div className="d-flex justify-content-center links">
					KODAN IO
				</div>
				
			</div>
		</div>
	</div>
     );
}

