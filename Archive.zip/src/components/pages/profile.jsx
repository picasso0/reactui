import { Navigate } from "react-router-dom";
import Swal from 'sweetalert2/dist/sweetalert2.js'

function Profile() {
    const handleDelete=()=>{
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
              confirmButton: 'btn btn-success',
              cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
          })
          
          swalWithBootstrapButtons.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
          }).then((result) => {
            if (result.isConfirmed) {

                //TODO delete here


              swalWithBootstrapButtons.fire(
                'Deleted!',
                'Your account has been deleted.',
                'success'
              )
            } else if (
              /* Read more about handling dismissals below */
              result.dismiss === Swal.DismissReason.cancel
            ) {
              swalWithBootstrapButtons.fire(
                'Cancelled',
                'Your acount is safe :)',
                'error'
              )
            }
          })
    }
    return ( 
        <div className="container profile rounded bg-white mt-5 mb-5">
    <div className="row">
        <div className="bg-c-lite-green col-md-3 border-right">
            <div className="d-flex flex-column align-items-center text-center p-3 py-5"><img className="rounded-circle mt-5" src="https://img.icons8.com/bubbles/100/000000/user.png" /><span className="font-weight-bold">Amelly</span><span className="text-black-50">amelly12@bbb.com</span><span> </span></div>
            <div className="row w-100 position-absolute bottom-0">
                <button className="btn btn-outline-white w-100"><i className="fas fa-users mr-2"></i>Users</button>
            </div>
        </div>
        <div className="col-md-9 border-right">
            <div className="p-3 py-5">
                <div className="d-flex justify-content-between align-items-center mb-3">
                    <h4 className="text-right">Profile</h4>
                </div>
                <div className="row mt-2">
                    <div className="col-md-6"><label className="labels font-weight-normal">Name</label><h6  className="ml-4 " >name</h6></div>
                    <div className="col-md-6"><label className="labels font-weight-normal">Surname</label><h6  className="ml-4 "  >family</h6></div>
                </div>
                <div className="row mt-3">
                    <div className="col-md-6"><label className="labels font-weight-normal">PhoneNumber</label><h6  className="ml-4 " >name</h6></div>
                    <div className="col-md-6"><label className="labels font-weight-normal">Address</label><h6  className="ml-4 " >name</h6></div>
                    <div className="col-md-6"><label className="labels font-weight-normal">Email ID</label><h6  className="ml-4 " >name</h6></div>
                    <div className="col-md-6"><label className="labels font-weight-normal">Education</label><h6  className="ml-4 " >name</h6></div>
                </div>
                <div className="row mt-3 mb-5">
                    <div className="col-md-6"><label className="labels font-weight-normal">Country</label><h6  className="ml-4 " >name</h6></div>
                    <div className="col-md-6"><label className="labels font-weight-normal">State/Region</label><h6  className="ml-4 " >name</h6></div>
                </div>
                <div className="pt-5 row w-100 position-absolute bottom-0">
                <a href="edit-profile" className="btn btn-info profile-button" type="button"><i className="fas fa-address-card mr-2"></i>Edit Profile</a>
                <button className="btn btn-danger profile-button" type="button"><i className="fas fa-user-times mr-2"></i>Delete Account</button>
                </div>
            </div>
        </div>
    </div>
</div>
     );
}

export default Profile;