import { useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";

function Navbar() {
  const[dashboard,setDashboard]=useState('')
  const[chart,setChart]=useState('')
  const[profile,setProfile]=useState('')
  const[dropdownshow,dropdownSet]=useState('')
  

  const handleUserButton=()=>{
    if(dropdownshow=='show'){

      dropdownSet('')
    }
    else{
      dropdownSet('show')
    }
  }
  const handleLogout=()=>{
    axios.post(process.env.REACT_APP_BACKEND_URL+ "/users/signout", 
		  )
		  .then(function (response) {
			if(response.status===200){
				Swal.fire({
					position: 'top-end',
					icon: 'success',
					title: 'Your work has been saved',
					showConfirmButton: false,
					timer: 1500
				  })
				  
				  localStorage.setItem('token',response.data.data.token.access)
				  window.location.reload(false);
				}
			else{
				Swal.fire({
					position: 'top-end',
					icon: 'error',
					title: response.data.err_msg,
					showConfirmButton: false,
					timer: 1500
				  })
				
				}
			
		  })
		  .catch(function (error) {
			Swal.fire({
				icon:'error',
				title:"oops :(",
				text:"sorry ! please contact to us to fixed this problem :("
			})
		  });
    console.log("remove")
    localStorage.removeItem('token')
  }
  
  useEffect(() => {
    // console.log(location)
    var href=window.location.href
    var href= href.split('/')[3]
    if(href=="/" || href==""){
      setDashboard('active')
    }
    else if(href=="chart"){
      setChart('active')
    }
    else if(href=="profile"){
      setProfile('active')
    }
    
  }, []);
  
    return ( 
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a className="navbar-brand" href="#">Fact.io</a>
        <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
          <li className={"nav-item "+dashboard}>
            <a className="nav-link" href="/">Dashboard <span className="sr-only">(current)</span></a>
          </li>
          <li className={"nav-item "+chart}>
            <a className="nav-link" href="/chart">Charts</a>
          </li>
          <li className={"nav-item "+profile}>
            <a className="nav-link" href="/profile">Profile</a>
          </li>

        </ul>
        <div className="dropdown show">
          <a className="text-white dropdown-toggle" onClick={handleUserButton} role="button" id="dropdownMenuLink" >
          <i className="fas fa-user mr-2"></i> username
          </a>
          <div className={"dropdown-menu "+dropdownshow} aria-labelledby="dropdownMenuLink">
           <a className="dropdown-item" href="profile"><i className="fas fa-address-card mr-2"></i>Profile</a>
            <a className="dropdown-item" href="users"><i className="fas fa-users mr-2"></i>Users</a>
            <a className="dropdown-item" onClick={handleLogout} href="/"><i className="fa fa-share-square mr-2"></i>LogOut</a>
          </div>
        </div>
      </div>
    </nav>
     );
}

export default Navbar;