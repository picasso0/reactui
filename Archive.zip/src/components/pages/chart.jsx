import { useEffect, useState } from 'react';
import { Tree, TreeNode } from 'react-organizational-chart';
import axios from "axios";
import { useAlert } from 'react-alert'
function Chart() {
    const alert = useAlert()
    const[data,setData]=useState([])
    const[halfShow,setHalfShow]=useState('')
    const[shadow,setShadow]=useState('')
    const[halfscreen,setHalfscreen]=useState({'key':"",'value':{'children':{}}})
    useEffect(() => {
        axios.post("http://127.0.0.1:8000/user/getChart", 
		  )
		  .then(function (response) {
        console.log(response)
			if(response.status===200){
				if (response.data.status===false){
					alert.error("chart get faild")
				}
				else{
				setData(response.data.data)
				alert.success("chart get successfully")
				}
			}
		  })
		  .catch(function (error) {
        alert.error("chart get faild")
			console.log(error);
		  });
      }, []);

      const handleHalfScreen=(key,value)=>{

          setHalfscreen({'key':key,'value':value})
          setHalfShow('show')
          setShadow('show')
      }
      const closeSlide=()=>{
        console.log("close")
        setHalfShow('')
        setShadow('')
    }
    return ( 
      <>
      <button onClick={closeSlide} className={'shadow '+shadow}></button>
      <div className={'half-screen bg-dark '+halfShow}>
      <div className='container text-center'>
              <div className='row pt-5 p-3 dash-border-white place-self-center bg-primary d-flex justify-content-center bg-primary h-300'>
                  <div className="col-12">
                  <h2 className='col-12 font-weight-bold'>{halfscreen.key}</h2>
                  </div>
                  <div className='col-6 justify-content-center d-flex'><span>permissions :  </span> <h4>{halfscreen.value.permissions}</h4></div>
                  <div className='col-6 justify-content-center d-flex'><span>filename :  </span> <h4>{halfscreen.value.filename}</h4></div>

              </div>
      <div className='row mt-3'>
      {Object.entries(halfscreen.value.children).map(([key,value])=>{
      return (
          <div key={key} onClick={()=>handleHalfScreen(key,value)} className='col-4 p-2 px-3 place-self-center'>
              <div className="col-12 half-item pt-3 bg-info h-150">
                  <div className="col-12">
                  <h2 className='col-12 font-weight-bold'>{key}</h2>
                  </div>
                  <div className='col-12 justify-content-center d-flex'><span>permissions :  {value.permissions}</span></div>
                  <div className='col-12 justify-content-center d-flex'><span>filename :  {value.filename}</span></div>
                  </div>
              </div>
      );})}
      </div>
      </div>
      </div>
        <div className='container-fluid pt-3'>
            
        {Object.entries(data).map(([key,value])=>{
            return (

      <Tree key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
          {Object.entries(value.children).map(([key,value])=>{
              return (
              <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}<div className='card-tree'><div className='d-flex'><span>file name : </span><h4>{value.filename}</h4></div><div className='d-flex'><span>permissions : </span><h4>{value.permissions}</h4></div></div></div>}>
                  {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    {Object.entries(value.children).map(([key,value])=>{
              return (
                <TreeNode key={key} label={<div onClick={()=>handleHalfScreen(key,value)}>{key}</div>}>
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                    </TreeNode>
              );
                  })}
                </TreeNode>
              );
               })}
      </Tree>
            );
 })} 
    
     
     </div>
     </>
     );
}

export default Chart;