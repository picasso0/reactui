function NotFound() {
    return ( 
        <div class="d-flex align-items-center h-100vh">
            <div class="col-md-12 text-center">
                <span class="display-1 d-block">404</span>
                <div class="mb-4 lead">The page you are looking for was not found.</div>
                <a href="/" class="btn btn-link">Back to Home</a>
            </div>
        </div>
     );
}

export default NotFound;