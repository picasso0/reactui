import { useState } from "react";
import axios from "axios";
import {  Navigate } from 'react-router-dom';
import Swal from 'sweetalert2/dist/sweetalert2.js'


export default function Login() {
	const [email,setEmail]=useState()
	const [password,setPassword]=useState()

	const handleSignUp=()=>{
		Swal.fire(({
    title: 'Sign Up',
    html:

      '<hr><div class="input-group form-group" ><div class="input-group-prepend"><span className="input-group-text"><i class="mt-2 fas fa-user"></i><div class="mt--10"><small class="font-10">username</small></div></span></div><input id="username" type="text" placeholder="usename" class="form-control"></div>' +
      '<div class="input-group form-group" ><div class="input-group-prepend"><span className="input-group-text"><i class="mt-2 fas fa-envelope"></i><div class="mt--10"><small class="font-10">email</small></div></span></div><input id="email" type="email" placeholder="email" class="form-control"></div>' +
      '<div class="input-group form-group" ><div class="input-group-prepend"><span className="input-group-text"><i class="mt-2 fas fa-lock"></i><div class="mt--10"><small class="font-10">password</small></div></span></div><input id="password" type="password" placeholder="password" class="form-control"></div>' +
      '<div class="input-group form-group" ><div class="input-group-prepend"><span className="input-group-text"><i class="mt-2 fas fa-lock"></i><div class="mt--10"><small class="font-10">verify</small></div></span></div><input id="verify" type="password" placeholder="verify password" class="form-control"></div><hr>' ,
	  focusConfirm: true,
	  confirmButtonText:
		'<i class="fa fa-user-plus"></i> sign up',
	  
  })).then((result) => {
			if (result.isConfirmed) {
				var empties="please fill ( "
				if((document.getElementById('username').value=="") || document.getElementById('email').value=="" || document.getElementById('password').value=="" || document.getElementById('verify').value==""){
					if(document.getElementById('username').value==""){
						empties=empties.concat(' username ,')
					}
					if(document.getElementById('email').value==""){
						empties=empties.concat(' email ,')
					}
					if(document.getElementById('password').value==""){
						empties=empties.concat(' password ,')
					}
					if(document.getElementById('verify').value==""){
						empties=empties.concat(' verify ,')
					}

					return	Swal.fire({
						icon: 'error',
						title: `please fill inputs !.`,
						text:empties.slice(0, -1)+' )'
					  })	
				}
				if(document.getElementById('password').value != document.getElementById('verify').value){
					return	Swal.fire({
						icon: 'error',
						title: `password and verify not same !.`
					  })	
				}
				
				var response=signup({
					'username':document.getElementById('username').value,
					'email':document.getElementById('email').value,
					'password':document.getElementById('password').value,
				})
			}
		  })
	}

	async function signup (signupInfo) {
		console.log(signupInfo)
		console.log(process.env.REACT_APP_LOGIN_URL)
		axios.post(process.env.REACT_APP_BACKEND_URL+ "/users/", 
			signupInfo
		  )
		  .then(function (response) {
			if(response.status===201){
					Swal.fire({
						icon:'success',
						title:"congratulation :)",
						text:"your account created successfully"
					})
				}
			else if(response.data.err==true){
					Swal.fire({
						icon:'error',
						title:"oops :(",
						text:response.data.err_msg
					})
				}
		  })
		  .catch(function (error) {
			Swal.fire({
				icon:'error',
				title:"oops :(",
				text:"sorry ! please contact to us to fixed this problem :("
			})
		  });
	}


	async function loginUser (loginInfo) {
		console.log(loginInfo)
		console.log(process.env.REACT_APP_LOGIN_URL)
		axios.post(process.env.REACT_APP_BACKEND_URL+ "users/signin/", 
			loginInfo
		  )
		  .then(function (response) {
			if(response.status===200){
				Swal.fire({
					position: 'top-end',
					icon: 'success',
					title: 'Your work has been saved',
					showConfirmButton: false,
					timer: 1500
				  })
				  
				  localStorage.setItem('token',response.data.data.token.access)
				  window.location.reload(false);
				}
			else{
				Swal.fire({
					position: 'top-end',
					icon: 'error',
					title: response.data.err_msg,
					showConfirmButton: false,
					timer: 1500
				  })
				
				}
			
		  })
		  .catch(function (error) {
			Swal.fire({
				icon:'error',
				title:"oops :(",
				text:"sorry ! please contact to us to fixed this problem :("
			})
		  });
	}

	const handleSubmit = async e => {
		e.preventDefault();
		await loginUser({
		  'email':email,
		  'password':password
		});
	  }

	if (localStorage.getItem('token')!==null){
		alert.show("you are loged in"
		)
		return <Navigate to="/?" />
	}
    return ( 
        <div className="d-flex justify-content-center h-100vh user bg-login">
		<div className="card">
			<div className="card-header">
				<h3>Sign In</h3>
			</div>
			<div className="card-body">
				<form>
					<div className="input-group form-group">
						<div className="input-group-prepend">
							<span className="input-group-text"><i className="fas fa-user"></i></span>
						</div>
						<input type="email" className="form-control" onChange={e => setEmail(e.target.value)}  placeholder="username" />
					</div>
					<div className="input-group form-group">
						<div className="input-group-prepend">
							<span className="input-group-text"><i className="fas fa-key"></i></span>
						</div>
						<input type="password" onChange={e => setPassword(e.target.value)} className="form-control" placeholder="password" autoComplete="on" />
					</div>
					<div className="row align-items-center remember">
						<input type="checkbox"/>Remember Me
					</div>
					<div className="row p-2 justify-content-center">
						<input type="submit" onClick={ handleSubmit  } value="Login" className="btn  float-right login_btn" />
						</div>
						<div>
				<p className="text-white">if have not any acounts <a onClick={handleSignUp} className="text-warning">create acount  &nbsp;</a>!</p>
				</div>
				</form>
				
			</div>
			<div className="card-footer">
				<div className="d-flex justify-content-center links">
					KODAN IO
				</div>
				
			</div>
		</div>
	</div>
     );
}

