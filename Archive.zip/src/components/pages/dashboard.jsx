export default function Dashboard() {
    return (
        <p>Dashboard</p>
      );
}

